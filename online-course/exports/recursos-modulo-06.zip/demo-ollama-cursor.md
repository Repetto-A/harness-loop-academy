# Demo — Ollama + Cursor (Módulo 6)

**Duración en video:** ~25 min (bloques 10:00–35:00) | **Repo:** `starter/harnessed-app`

## Pre-requisitos (grabar una vez)

- Node 20+
- Ollama instalado: https://ollama.com
- Modelos precargados (ajustar a tu VRAM):

```bash
ollama --version
ollama pull qwen2.5-coder:7b
# Opcional si hay GPU: ollama pull deepseek-r1:8b
ollama list
```

- Cursor: Settings → Models → Ollama en `http://localhost:11434`
- Repo clonado, `npm install` en `starter/harnessed-app`

## Parte 1 — Terminal (10:00–15:00)

```bash
ollama run qwen2.5-coder:7b "Explicá en 3 bullets qué hace users.js en una API REST"
```

Mostrar latencia y calidad en tarea trivial.

## Parte 2 — Cursor chat (15:00–25:00)

1. Abrir `starter/harnessed-app` en Cursor
2. Chat nuevo → modelo `qwen2.5-coder:7b`
3. Prompt:

```text
Leé starter/harnessed-app/src/users.js y proponé un test para el caso 404 en GET /api/users/:id/display-name.
No implementes todavía; solo el plan y el esqueleto del test.
```

4. Mostrar que el contexto del archivo importa más que el modelo gigante.

## Parte 3 — Agent acotado (25:00–32:00)

Mismo repo, Agent mode con modelo local:

```text
En src/routes/users.js, asegurate de que el handler de display-name devuelve 404 cuando el usuario no existe.
Solo tocá ese archivo y el test relacionado. Corré npm test al final.
```

**Si tarda mucho en grabación:** cortar a jump-cut con branch `demo/mod6-local-fix` ya preparado.

## Parte 4 — Contraste frontera (32:00–35:00)

Mismo prompt con Claude/GPT en Cursor (1 min):

- Calidad en edge cases
- Velocidad
- Costo / privacidad

Frase:

> Local para iterar y datos sensibles; frontera para agentes largos en monorepos.

## Parte 5 — Caso JSON (35:00–45:00 en guion principal)

Prompt fijo (chat local):

```text
Dado este JSON de ticket de soporte, devolvé SOLO JSON con campos: categoria, prioridad, resumen.
{"id": 42, "texto": "No puedo login desde ayer, urgente para demo con cliente"}
```

Repetir con 2 ejemplos más. Mencionar golden set (`GoldenSetEvaluator` en slide).

## Plan B

| Fallo | Mitigación |
|-------|------------|
| Ollama no arranca | Mostrar `ollama list` + captura Settings Cursor de sesión anterior |
| Modelo lento | Usar 3B/7B; advertir en slide Setup |
| Agent se cuelga | Pre-grabar terminal; voz en off sobre capturas |

## Checklist pre-grabación

- [ ] `ollama list` muestra modelo pulled
- [ ] Cursor detecta Ollama
- [ ] `harnessed-app` abre sin errores
- [ ] Cerrar notificaciones / modo no molestar
