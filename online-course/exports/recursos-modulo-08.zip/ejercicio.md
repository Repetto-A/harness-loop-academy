# Ejercicio — Bootstrap harness en Cursor (Módulo 8)

**Duración:** 20 min (recorte de Lab 01)

Adaptado de [`labs/lab-01-bootstrap-harness.md`](../../../labs/lab-01-bootstrap-harness.md).

## Objetivo

Tener en tu repo (o fork de `harnessed-app`) un harness mínimo funcional en Cursor.

## Pasos

### A — AGENTS.md (8 min)

1. Copiá [`templates/AGENTS.md.template`](../../../templates/AGENTS.md.template) a la raíz.
2. Completá con datos reales de tu stack (máx. ~120 líneas).

### B — Una regla (5 min)

Creá `.cursor/rules/<dominio>.mdc` con glob acotado (ej. `src/api/**/*.js`).

### C — Un skill (5 min)

Creá `.cursor/skills/<nombre>/SKILL.md` para algo que repitás (review API, migraciones, a11y).

### D — Validación (2 min)

Agregá o documentá en `package.json`:

```json
"validate:quick": "npm run lint && npm test"
```

## Entregable

- [ ] `AGENTS.md` en raíz
- [ ] 1 archivo en `.cursor/rules/`
- [ ] 1 skill en `.cursor/skills/`
- [ ] Captura: Agent leyendo AGENTS.md en un chat nuevo

## Criterios de éxito

El agente puede citar tu boot sequence y correr `validate:quick` sin que se lo pidas en el prompt.
