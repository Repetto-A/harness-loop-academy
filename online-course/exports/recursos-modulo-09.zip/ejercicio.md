# Ejercicio — Dibujá tu arquitectura (Módulo 9)

**Duración:** 20 min

## Objetivo

Diseñar tu stack IA 2026: qué va en el repo, qué en MCP, qué en local vs API.

## Parte 1 — Diagrama (10 min)

Completá un diagrama (Mermaid, Excalidraw o PNG) con:

- IDE (Cursor)
- Git / repo
- Harness: AGENTS, rules, skills, docs, validate
- Capa externa: MCP, Ollama, APIs frontera

Plantilla Mermaid en [`arquitectura-recomendada.md`](../../recursos/arquitectura-recomendada.md).

## Parte 2 — MCPs (5 min)

Listá:

| Usaría | No usaría | Razón |
|--------|-----------|-------|
| | | |
| | | |
| | | |

## Parte 3 — Boot sequence (5 min)

Definí 4 archivos que tu agente debe leer **siempre** al iniciar una tarea en tu repo real.

Ejemplo academy:

1. `AGENTS.md`
2. `docs/current-state.md`
3. `docs/api-contract.md`
4. Spec del feature activo

## Entregable

- Diagrama (PNG o `.md`)
- Tabla MCP (3 sí / 3 no)
- Boot sequence en 4 líneas

## Criterios de éxito

- [ ] El harness está **en el repo**, no solo en prompts del chat
- [ ] Al menos un MCP con razón clara (no “porque está de moda”)
- [ ] Boot sequence es ejecutable (archivos existen o planeás crearlos)
