# Demo — MCP y workflow Git (Módulo 9)

## Demo MCP

### Engram (memoria entre sesiones)

1. Cursor → MCP panel → Engram activo
2. Prompt:

```text
mem_search: boot sequence harness academy
```

3. Si vacío, `mem_save` con decisión de boot sequence
4. Nuevo chat → verificar que el agente recupera contexto vía MCP

### Context7 (docs actualizadas)

```text
Usá Context7: ¿cuál es la forma recomendada de definir route handlers en Next.js 15?
```

Comparar respuesta con y sin MCP (1 min cada una).

## Demo Workflow Git

**Repo:** `starter/harnessed-app`

```bash
git status
git checkout -b feat/ejemplo-mod9
```

### Spec mínima (`specs/add-health-version/spec.md`)

```markdown
# Health endpoint

## Objetivo
GET /api/health devuelve `{ "status": "ok", "version": "<from package.json>" }`.

## Criterios
- 200 JSON
- Test en tests/integration/
- validate:closeout pasa
```

### Prompt Agent

```text
Implementá specs/add-health-version/spec.md.
Seguí AGENTS.md. Al terminar: validate:closeout y Closeout.
```

### Cierre workflow

```bash
npm run validate:closeout
git add -A
git commit -m "feat(api): health endpoint with version"
git log -1 --oneline
```

## Plan B

- MCP caído: explicar con slide diagrama + grabación previa de panel MCP
- validate lento: mostrar output parcial y commit ya hecho en branch backup
