# Arquitectura recomendada 2026 — desarrollo con IA

**Módulo 9** | Handout descargable

## Capas del sistema

```mermaid
flowchart TB
  subgraph dev [Developer]
    IDE[Cursor_IDE]
    Git[Git_Repo]
  end
  subgraph harness [Harness_en_repo]
    AGENTS[AGENTS.md]
    Rules[cursor_rules]
    Skills[skills]
    Docs[docs_y_specs]
    Validate[validate_scripts]
  end
  subgraph external [Capa_externa_opcional]
    MCP[MCP_servers]
    OSS[Ollama_local]
    API[APIs_frontera]
  end
  IDE --> AGENTS
  IDE --> Rules
  IDE --> Skills
  IDE --> MCP
  IDE --> OSS
  IDE --> API
  Git --> Docs
  Validate --> Git
```

## Niveles de madurez

### Nivel 1 — Solo (dev individual)

- `AGENTS.md` (~120 líneas máx)
- 1 skill de dominio
- Script `validate:quick` o `validate:closeout`
- Modelo frontera en Cursor

**Objetivo:** el agente no inventa convenciones ni cierra sin evidencia.

### Nivel 2 — Equipo chico

- Todo lo anterior +
- `.cursor/rules/*.mdc` por dominio (API, UI, DB)
- `docs/current-state.md` + specs en `docs/specs/` o `specs/`
- MCP de documentación (Context7) o memoria (Engram)

**Objetivo:** contexto portable entre devs y sesiones.

### Nivel 3 — Producción con datos sensibles

- Todo lo anterior +
- Ollama local para tareas con datos que no salen de la red
- Golden set para evaluar modelos OSS vs API
- CI que corre `validate:*` en PR

**Objetivo:** repetibilidad y gates automáticos.

## AGENTS.md vs CLAUDE.md vs rules

| Archivo | Rol |
|---------|-----|
| `AGENTS.md` | Contrato portable (Cursor, Copilot, Claude Code, agents) |
| `CLAUDE.md` | Equivalente en ecosistema Claude Code |
| `.cursor/rules/` | Reglas scoped por glob (archivo/carpeta) |
| `docs/current-state.md` | Hechos durables que el chat no recuerda |
| Skills | Procedimientos repetibles bajo demanda |

## MCP — qué sí y qué no

| Usar MCP para | No usar MCP para |
|---------------|------------------|
| Docs de librerías actualizadas | Texto estático del repo → skills |
| Memoria entre sesiones (Engram) | Reemplazar `AGENTS.md` |
| APIs externas (DB, tickets) | Duplicar lo que ya está en `docs/` |

## Workflow Git recomendado

1. `git checkout -b feat/nombre`
2. Spec en `docs/specs/` o `specs/<feature>/spec.md`
3. Agent implementa siguiendo spec + `AGENTS.md`
4. `npm run validate:closeout`
5. Commit + PR con diff review

## Referencias

- [Model Context Protocol](https://modelcontextprotocol.io)
- Repo academy: `starter/harnessed-app`
- Setup cloud agents: `docs/SETUP-CLOUD.md`
